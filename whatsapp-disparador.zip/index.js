
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const venom = require('venom-bot');
const fs = require('fs');
const readline = require('readline');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const upload = multer({ dest: 'uploads/' });

let client;

venom
  .create()
  .then((c) => {
    client = c;
    console.log('✅ Cliente conectado!');
  })
  .catch((err) => {
    console.error('Erro ao iniciar o cliente:', err);
  });

// Endpoint para envio de mensagens
app.post('/send', upload.single('numbers'), async (req, res) => {
  const message = req.body.message;
  const file = req.file;

  if (!file) return res.status(400).send('Arquivo de contatos não enviado');

  const fileStream = fs.createReadStream(file.path);
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity,
  });

  for await (const number of rl) {
    const formattedNumber = number.trim() + '@c.us';
    await client.sendText(formattedNumber, message);
    console.log(`Mensagem enviada para: ${number}`);
  }

  fs.unlinkSync(file.path); // remove arquivo após uso

  res.send('Mensagens enviadas com sucesso!');
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});
